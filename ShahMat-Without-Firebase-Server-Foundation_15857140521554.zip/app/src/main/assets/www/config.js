window.SHAHMAT_CONFIG={serverUrl:'http://localhost:3000'};
