@echo off
chcp 65001 >nul
start "" "%~dp0app\src\main\assets\www\index.html"
