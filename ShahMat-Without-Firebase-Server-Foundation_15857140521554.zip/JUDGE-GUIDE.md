# راهنمای ارائه و داوری شاه‌مات

## معرفی کوتاه
شاه‌مات یک محیط آموزشی و تمرینی شطرنج فارسی است که بازی با ربات، حالت مربی، تحلیل بازی، آموزش مات، معما، تمرین گشایش و گزارش پیشرفت را در یک برنامه جمع می‌کند.

## مسیر پیشنهادی دمو (۵ تا ۷ دقیقه)
1. از صفحهٔ خانه، تمرین روزانه را باز کنید و یک مسئله را حل کنید.
2. به آزمایشگاه گشایش‌ها بروید؛ یک گشایش را انتخاب کنید و حرکت‌ها را روی صفحه مرور کنید.
3. یک بازی با ربات را شروع کنید و چند حرکت انجام دهید.
4. پس از پایان بازی، تاریخچه را باز کنید و تحلیل و PGN را نشان دهید.
5. صفحهٔ دستاوردها و گزارش آمار را نمایش دهید.
6. تنظیمات را باز کنید و پشتیبان‌گیری را توضیح دهید.
7. نسخهٔ اندروید را از APK ساخته‌شده توسط GitHub Actions اجرا کنید.

## اجزای فنی
- رابط کاربری: HTML، CSS و JavaScript
- موتور حرکت و جست‌وجوی شطرنج: موتور داخلی JavaScript
- نگهداری داده‌ها: LocalStorage در نسخهٔ مرورگری و WebView
- پوستهٔ اندروید: Java Android WebView و AndroidX WebKit
- ساخت APK: Gradle و GitHub Actions

## نوآوری‌های قابل ارائه
- محیط فارسی و راست‌به‌چپ
- حالت مربی و تحلیل حرکت‌ها
- برنامهٔ تمرین روزانه و مسیر پیشرفت
- کتابخانهٔ گشایش با مرور حرکت روی صفحه
- دستاوردهای مبتنی بر فعالیت واقعی کاربر
- انتقال اطلاعات با پشتیبان JSON و بازیابی آن

## محدودیت‌ها و کارهای باقی‌مانده
- بخش آنلاین، بازی با دوست، چت زنده و جدول رتبه‌بندی برای کارکرد عمومی به Firebase با احراز هویت و قوانین امنیتی محدود نیاز دارند. فایل `config.js` فعلاً URL خالی دارد؛ بنابراین آنلاین واقعی فعال نیست.
- در این نسخه Stockfish جداگانه ادغام نشده است؛ تحلیل از موتور داخلی پروژه استفاده می‌کند.
- نسخهٔ ویندوز فعلی نسخهٔ مرورگری قابل اجرا با فایل BAT است، نه فایل EXE مستقل.
- APK در محیط ویرایش ساخته یا روی دستگاه واقعی آزمایش نشده است. باید گردش‌کار GitHub Actions اجرا شود و خروجی روی گوشی/تبلت آزمایش گردد.

## معیارهای پیشنهادی برای ارزیابی
- صحت قوانین شطرنج و پایداری بازی
- کیفیت توضیح مربی و تحلیل
- ارزش آموزشی و قابل سنجش بودن پیشرفت
- سهولت استفاده و کیفیت رابط فارسی
- مستندات، معماری و شفافیت محدودیت‌ها


## Added feature: Offline tournament manager
The tournament screen supports local knockout events for 2–64 distinct participant names. It shuffles seeding, creates a power-of-two bracket with byes, advances completed rounds, records winners, and identifies the champion. Data persists on the device.

## Honest scope statement
Online matchmaking and rating code require a correctly configured authenticated backend. No live chat or production-secure online tournament service is included in this build. Judges should be shown the offline tournament workflow separately from the online matchmaking scaffold.
