# شاه‌مات ULTIMATE 1.1.0

شاه‌مات یک پروژهٔ آموزشی شطرنج فارسی با نسخهٔ Android WebView و نسخهٔ مرورگری ویندوز است.

## امکانات پیاده‌سازی‌شده در این بسته
- بازی آفلاین با ۳۰ ربات با سطوح اسمی ۲۵۰ تا ۳۲۰۰
- بازی با مربی و تحلیل حرکت‌ها با موتور داخلی JavaScript
- مرور و تحلیل بازی‌های ذخیره‌شده
- خروجی PGN برای بازی‌ها و خروجی یک‌جای تاریخچه
- تاریخچهٔ بازی‌ها و داشبورد آمار
- آموزش الگوهای مات، معماهای مات در یک و دو حرکت و نردبان ربات‌ها
- آزمایشگاه گشایش‌ها: انتخاب خط، مرور حرکت‌به‌حرکت روی صفحه و کپی PGN
- تمرین روزانه بر اساس تاریخ روز
- دستاوردهای پویا بر اساس بازی‌ها و پیشرفت واقعی ذخیره‌شده
- پوستهٔ روشن/تیره/خودکار و تنظیم صدا
- پشتیبان‌گیری و بازیابی اطلاعات با JSON
- نسخهٔ اندروید با انتخاب‌گر فایل برای بازیابی پشتیبان
- گردش‌کار GitHub Actions برای ساخت APK

## اجرای نسخهٔ ویندوز
روی ویندوز فایل `Run-ShahMat-Windows.bat` را اجرا کن. این روش صفحهٔ برنامه را در مرورگر پیش‌فرض باز می‌کند؛ فایل EXE مستقل نیست. برای بهترین سازگاری از مرورگر Chromium به‌روز استفاده کن. روی Windows 7 ممکن است نسخهٔ مرورگر قدیمی باشد و بعضی قابلیت‌های جدید وب پشتیبانی نشوند.

## ساخت APK اندروید
1. پروژه را در GitHub قرار بده و به شاخهٔ `main` یا `master` push کن.
2. از بخش **Actions**، گردش‌کار **Build APK** را اجرا کن.
3. فایل `ShahMat.apk` را از Artifact دریافت کن.
4. APK را روی دستگاه واقعی نصب و آزمایش کن.

نیازمندی ساخت محلی: JDK 17، Android SDK و Gradle 8.7.

## وضعیت قابلیت آنلاین
بخش بازی آنلاین و اتاق دوست در کد پایه وجود دارد، اما `app/src/main/assets/www/config.js` فعلاً `firebaseUrl` خالی دارد. بنابراین آنلاین عمومی در این بسته آمادهٔ استفاده نیست. برای فعال‌سازی باید Firebase Realtime Database، احراز هویت و Security Rules محدود و آزمایش‌شده تنظیم شوند. هرگز قوانین عمومی با دسترسی نوشتن برای همه فعال نکن.

چت زنده، تورنمنت آنلاین و همگام‌سازی ابری در این نسخه به‌عنوان قابلیت کامل پیاده‌سازی نشده‌اند؛ نباید در ارائه ادعا شوند.

## موتور و تحلیل
در این نسخه از موتور داخلی JavaScript موجود در پروژه استفاده شده است. Stockfish جداگانه ادغام نشده و هیچ ادعایی دربارهٔ هم‌سطح بودن قدرت تحلیل با Chess.com وجود ندارد.

## مستندات داوری
فایل `JUDGE-GUIDE.md` مسیر پیشنهادی دموی کوتاه، معماری، نوآوری‌ها و محدودیت‌های فنی را توضیح می‌دهد.

## امنیت و حریم خصوصی
داده‌های محلی در LocalStorage مرورگر/WebView نگهداری می‌شوند. پیش از انتشار عمومی، سیاست حریم خصوصی، پشتیبان‌گیری، امنیت پایگاه داده و مجوزهای کتابخانه‌ها باید بازبینی شوند.

## وضعیت آزمون
نحو JavaScript با Node.js بررسی شده است و آرشیو ZIP نیز پس از بسته‌بندی کنترل می‌شود. ساخت APK و تست واقعی روی Android در این محیط انجام نشده؛ نتیجهٔ موفق GitHub Actions و آزمایش دستگاهی برای تأیید نهایی لازم است.

## نصب روی اندروید
این مخزن سورس پروژه اندروید است و APK از پیش ساخته‌شده داخل ZIP نیست. برای ساخت APK، راهنمای `BUILD-APK-ON-GITHUB.md` را دنبال کن؛ گردش‌کار GitHub Actions فایل نصب `ShahMat.apk` را تولید می‌کند.


## Ultimate update (v2.0)
- Added a persistent offline knockout tournament manager (2–64 participants), randomized bracket seeding, byes, round progression, winner recording, champion display, and tournament deletion.
- Existing chess engine, bot play, coach/review, puzzles, lessons, opening library, achievements, online matchmaking hooks, Elo/rating board, PGN export, and backup/restore remain in the source.
- Tournament data is stored locally on the device. It is not a cross-device or online tournament service.

## Important online-service requirements
The online matchmaking/rating code is a client integration scaffold. The Firebase URL is blank by default. Do not publish it with permissive database rules: a production service needs Firebase Authentication, restrictive Realtime Database rules, server-side validation of moves/results/Elo, abuse controls, and moderation/reporting for chat. This archive does not claim to provide a production-secure public multiplayer service or live chat.

## Build status
The GitHub Actions workflow builds a debug APK. A debug APK is suitable for testing, not Play Store release. The APK must be built by GitHub Actions or Android build tools and then installed/tested on real devices. This source archive itself is not an APK.
